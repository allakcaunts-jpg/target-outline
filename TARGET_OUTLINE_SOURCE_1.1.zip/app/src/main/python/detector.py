"""Experimental on-device candidate detector.

It only segments saturated visible pixels and groups nearby components. It is
NOT a trained Brawl Stars character classifier: bright effects, map art and UI
can create false positives, and similarly colored objects can be missed.

Input is packed RGBA8888 bytes. Output boxes are [left, top, right, bottom].
No networking, screenshots, or disk writes are performed here.
"""
import json

_PREVIOUS_BOXES = []


def _is_color_pixel(r, g, b, sensitivity):
    high = max(r, g, b)
    low = min(r, g, b)
    spread = high - low
    # Higher sensitivity accepts less saturated pixels, which also increases
    # false positives. Keep a brightness floor to reduce dark background noise.
    spread_threshold = max(18, 88 - int(sensitivity))
    return high >= 82 and spread >= spread_threshold and spread / max(high, 1) >= 0.24


def _components(mask, grid_width, grid_height, min_area):
    seen = bytearray(len(mask))
    result = []
    for start in range(len(mask)):
        if not mask[start] or seen[start]:
            continue
        stack = [start]
        seen[start] = 1
        min_x = max_x = start % grid_width
        min_y = max_y = start // grid_width
        count = 0
        while stack:
            point = stack.pop()
            x = point % grid_width
            y = point // grid_width
            count += 1
            if x < min_x: min_x = x
            if x > max_x: max_x = x
            if y < min_y: min_y = y
            if y > max_y: max_y = y
            y0 = max(0, y - 1)
            y1 = min(grid_height, y + 2)
            x0 = max(0, x - 1)
            x1 = min(grid_width, x + 2)
            for ny in range(y0, y1):
                row = ny * grid_width
                for nx in range(x0, x1):
                    neighbor = row + nx
                    if mask[neighbor] and not seen[neighbor]:
                        seen[neighbor] = 1
                        stack.append(neighbor)
        box_width = max_x - min_x + 1
        box_height = max_y - min_y + 1
        box_area = box_width * box_height
        density = count / max(box_area, 1)
        if count < min_area or box_width < 4 or box_height < 5:
            continue
        if density < 0.055:
            continue
        aspect = box_width / max(box_height, 1)
        if aspect < 0.28 or aspect > 2.8:
            continue
        if box_area > grid_width * grid_height * 0.16:
            continue
        result.append([min_x, min_y, max_x, max_y, count])
    return result


def _merge_nearby(components, gap=3):
    boxes = [box[:] for box in components]
    changed = True
    while changed:
        changed = False
        merged = []
        while boxes:
            current = boxes.pop(0)
            index = 0
            while index < len(boxes):
                other = boxes[index]
                separated_x = max(0, max(current[0], other[0]) - min(current[2], other[2]) - 1)
                separated_y = max(0, max(current[1], other[1]) - min(current[3], other[3]) - 1)
                if separated_x <= gap and separated_y <= gap:
                    current = [
                        min(current[0], other[0]),
                        min(current[1], other[1]),
                        max(current[2], other[2]),
                        max(current[3], other[3]),
                        current[4] + other[4],
                    ]
                    boxes.pop(index)
                    changed = True
                else:
                    index += 1
            merged.append(current)
        boxes = merged
    return boxes


def _smooth(current):
    global _PREVIOUS_BOXES
    smoothed = []
    previous_used = set()
    for box in current:
        best_index = -1
        best_iou = 0.0
        for index, old in enumerate(_PREVIOUS_BOXES):
            if index in previous_used:
                continue
            left = max(box[0], old[0])
            top = max(box[1], old[1])
            right = min(box[2], old[2])
            bottom = min(box[3], old[3])
            intersection = max(0, right - left) * max(0, bottom - top)
            area_a = max(1, (box[2] - box[0]) * (box[3] - box[1]))
            area_b = max(1, (old[2] - old[0]) * (old[3] - old[1]))
            iou = intersection / max(area_a + area_b - intersection, 1)
            if iou > best_iou:
                best_iou = iou
                best_index = index
        if best_index >= 0 and best_iou >= 0.12:
            old = _PREVIOUS_BOXES[best_index]
            previous_used.add(best_index)
            smoothed.append([
                int(old[0] * 0.35 + box[0] * 0.65),
                int(old[1] * 0.35 + box[1] * 0.65),
                int(old[2] * 0.35 + box[2] * 0.65),
                int(old[3] * 0.35 + box[3] * 0.65),
            ])
        else:
            smoothed.append(box[:4])
    _PREVIOUS_BOXES = [box[:] for box in smoothed]
    return smoothed


def detect_frame(rgba, width, height, sensitivity=50, min_area=18):
    """Return JSON boxes for a single packed RGBA8888 image frame."""
    width = int(width)
    height = int(height)
    sensitivity = max(25, min(85, int(sensitivity)))
    min_area = max(8, min(44, int(min_area)))
    if width <= 0 or height <= 0:
        return json.dumps({"boxes": []})
    try:
        view = memoryview(rgba)
    except TypeError:
        view = memoryview(bytes(rgba))
    if len(view) < width * height * 4:
        return json.dumps({"boxes": []})

    # 2x2 pixel sampling reduces per-frame CPU use on phones.
    step = 2
    grid_width = (width + step - 1) // step
    grid_height = (height + step - 1) // step
    mask = bytearray(grid_width * grid_height)

    for gy in range(grid_height):
        y = gy * step
        source_row = y * width * 4
        target_row = gy * grid_width
        for gx in range(grid_width):
            x = gx * step
            index = source_row + x * 4
            r = view[index] & 255
            g = view[index + 1] & 255
            b = view[index + 2] & 255
            if _is_color_pixel(r, g, b, sensitivity):
                mask[target_row + gx] = 1

    components = _components(mask, grid_width, grid_height, min_area)
    components = _merge_nearby(components, gap=2)
    boxes = []
    for x1, y1, x2, y2, area in components:
        left = max(0, x1 * step - 2)
        top = max(0, y1 * step - 2)
        right = min(width, (x2 + 1) * step + 2)
        bottom = min(height, (y2 + 1) * step + 2)
        if right - left < 8 or bottom - top < 10:
            continue
        boxes.append([left, top, right, bottom])

    boxes.sort(key=lambda b: (b[2] - b[0]) * (b[3] - b[1]), reverse=True)
    boxes = _smooth(boxes[:10])
    return json.dumps({"boxes": boxes})


def reset_tracking():
    """Clear one-frame smoothing history (useful for tests)."""
    global _PREVIOUS_BOXES
    _PREVIOUS_BOXES = []
