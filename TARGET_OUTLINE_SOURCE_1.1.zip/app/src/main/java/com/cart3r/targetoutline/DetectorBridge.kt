package com.cart3r.targetoutline

import android.content.Context
import com.chaquo.python.Python
import com.chaquo.python.android.AndroidPlatform
import org.json.JSONObject

object DetectorBridge {
    @Volatile private var python: Python? = null

    @Synchronized
    private fun getPython(context: Context): Python {
        val current = python
        if (current != null) return current
        if (!Python.isStarted()) {
            Python.start(AndroidPlatform(context.applicationContext))
        }
        return Python.getInstance().also { python = it }
    }

    fun detect(
        context: Context,
        rgba: ByteArray,
        width: Int,
        height: Int,
        sensitivity: Int,
        minArea: Int
    ): List<Box> {
        val module = getPython(context).getModule("detector")
        val response = module.callAttr(
            "detect_frame", rgba, width, height, sensitivity, minArea
        ).toString()
        val output = mutableListOf<Box>()
        val boxes = JSONObject(response).optJSONArray("boxes") ?: return output
        for (index in 0 until boxes.length()) {
            val item = boxes.optJSONArray(index) ?: continue
            if (item.length() != 4) continue
            val left = item.optInt(0)
            val top = item.optInt(1)
            val right = item.optInt(2)
            val bottom = item.optInt(3)
            if (right > left && bottom > top) output.add(Box(left, top, right, bottom))
        }
        return output
    }
}

data class Box(val left: Int, val top: Int, val right: Int, val bottom: Int)
