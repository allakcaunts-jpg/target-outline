package com.cart3r.targetoutline

import android.content.Context
import android.graphics.Canvas
import android.graphics.Paint
import android.graphics.RectF
import android.view.View

class OverlayView(context: Context) : View(context) {
    private val paint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        color = 0xFFFF263F.toInt()
        style = Paint.Style.STROKE
        strokeWidth = 3f
        strokeCap = Paint.Cap.ROUND
        strokeJoin = Paint.Join.ROUND
    }

    @Volatile private var currentBoxes: List<Box> = emptyList()
    @Volatile private var sourceWidth = 1
    @Volatile private var sourceHeight = 1

    fun update(newBoxes: List<Box>, frameWidth: Int, frameHeight: Int, lineWidth: Float) {
        currentBoxes = newBoxes
        sourceWidth = frameWidth.coerceAtLeast(1)
        sourceHeight = frameHeight.coerceAtLeast(1)
        paint.strokeWidth = lineWidth.coerceIn(1f, 8f)
        postInvalidateOnAnimation()
    }

    override fun onDraw(canvas: Canvas) {
        super.onDraw(canvas)
        val scaleX = width.toFloat() / sourceWidth
        val scaleY = height.toFloat() / sourceHeight
        for (box in currentBoxes) {
            val rect = RectF(
                box.left * scaleX,
                box.top * scaleY,
                box.right * scaleX,
                box.bottom * scaleY
            )
            canvas.drawRoundRect(rect, 7f, 7f, paint)
        }
    }
}
