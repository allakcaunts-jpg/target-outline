package com.cart3r.targetoutline

import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.Service
import android.content.Context
import android.content.Intent
import android.content.pm.ServiceInfo
import android.graphics.PixelFormat
import android.hardware.display.DisplayManager
import android.hardware.display.VirtualDisplay
import android.media.Image
import android.media.ImageReader
import android.media.projection.MediaProjection
import android.media.projection.MediaProjectionManager
import android.os.Build
import android.os.Handler
import android.os.HandlerThread
import android.os.IBinder
import android.os.SystemClock
import android.provider.Settings
import android.util.DisplayMetrics
import android.util.Log
import android.view.Gravity
import android.view.WindowManager
import java.nio.ByteBuffer
import kotlin.math.roundToInt

class CaptureService : Service() {
    companion object {
        const val ACTION_START = "com.cart3r.targetoutline.START"
        const val EXTRA_RESULT_CODE = "resultCode"
        const val EXTRA_DATA = "projectionData"
        private const val CHANNEL_ID = "target_outline_capture"
        private const val NOTIFICATION_ID = 73
        private const val CAPTURE_WIDTH = 480
        private const val PREFS = "target_outline_settings"
        private const val TAG = "TargetOutline"
    }

    private var projection: MediaProjection? = null
    private var projectionCallback: MediaProjection.Callback? = null
    private var imageReader: ImageReader? = null
    private var virtualDisplay: VirtualDisplay? = null
    private var overlay: OverlayView? = null
    private var windowManager: WindowManager? = null
    private var workerThread: HandlerThread? = null
    private var worker: Handler? = null
    private var lastFrameAt = 0L
    private var frameWidth = CAPTURE_WIDTH
    private var frameHeight = 270

    override fun onBind(intent: Intent?): IBinder? = null

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        if (intent?.action != ACTION_START) {
            stopSelf(startId)
            return START_NOT_STICKY
        }
        // Ignore duplicate START taps: a MediaProjection token is one-session only.
        if (projection != null) return START_NOT_STICKY
        createNotificationChannel()
        val notification = buildNotification()
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.Q) {
            startForeground(
                NOTIFICATION_ID,
                notification,
                ServiceInfo.FOREGROUND_SERVICE_TYPE_MEDIA_PROJECTION
            )
        } else {
            startForeground(NOTIFICATION_ID, notification)
        }
        startProjection(intent)
        return START_NOT_STICKY
    }

    private fun startProjection(intent: Intent) {
        if (!Settings.canDrawOverlays(this)) {
            stopSelf()
            return
        }

        val data: Intent? = if (Build.VERSION.SDK_INT >= 33) {
            intent.getParcelableExtra(EXTRA_DATA, Intent::class.java)
        } else {
            @Suppress("DEPRECATION")
            intent.getParcelableExtra(EXTRA_DATA)
        }
        if (data == null) {
            Log.e(TAG, "MediaProjection consent data is missing")
            stopSelf()
            return
        }

        workerThread = HandlerThread("target-outline-frames").also { it.start() }
        worker = Handler(workerThread!!.looper)

        val metrics = DisplayMetrics()
        val wm = getSystemService(Context.WINDOW_SERVICE) as WindowManager
        @Suppress("DEPRECATION")
        wm.defaultDisplay.getRealMetrics(metrics)
        val longSide = maxOf(metrics.widthPixels, metrics.heightPixels).coerceAtLeast(1)
        val shortSide = minOf(metrics.widthPixels, metrics.heightPixels).coerceAtLeast(1)
        frameWidth = CAPTURE_WIDTH
        frameHeight = (CAPTURE_WIDTH.toFloat() * shortSide / longSide).roundToInt().coerceAtLeast(1)

        try {
            val manager = getSystemService(Context.MEDIA_PROJECTION_SERVICE) as MediaProjectionManager
            val resultCode = intent.getIntExtra(EXTRA_RESULT_CODE, 0)
            projection = manager.getMediaProjection(resultCode, data)
            projectionCallback = object : MediaProjection.Callback() {
                override fun onStop() {
                    Log.i(TAG, "MediaProjection stopped by the system/user")
                    stopSelf()
                }
            }
            // Android requires the callback to be registered before createVirtualDisplay.
            projection?.registerCallback(projectionCallback!!, worker)

            imageReader = ImageReader.newInstance(
                frameWidth, frameHeight, PixelFormat.RGBA_8888, 2
            )
            imageReader?.setOnImageAvailableListener({ reader ->
                val image = reader.acquireLatestImage() ?: return@setOnImageAvailableListener
                try {
                    val settings = getSharedPreferences(PREFS, MODE_PRIVATE)
                    val fps = settings.getInt("fps", 10).coerceIn(5, 15)
                    val interval = 1000L / fps
                    val now = SystemClock.elapsedRealtime()
                    if (now - lastFrameAt >= interval) {
                        lastFrameAt = now
                        processImage(image, settings)
                    }
                } catch (error: Exception) {
                    Log.e(TAG, "Frame processing failed", error)
                } finally {
                    image.close()
                }
            }, worker)

            virtualDisplay = projection?.createVirtualDisplay(
                "TargetOutlineDisplay",
                frameWidth,
                frameHeight,
                metrics.densityDpi,
                DisplayManager.VIRTUAL_DISPLAY_FLAG_AUTO_MIRROR,
                imageReader?.surface,
                null,
                worker
            )
            if (virtualDisplay == null) throw IllegalStateException("Could not create capture display")
            showOverlay()
        } catch (error: Exception) {
            Log.e(TAG, "Unable to start screen analysis", error)
            stopSelf()
        }
    }

    private fun processImage(image: Image, settings: android.content.SharedPreferences) {
        val width = image.width
        val height = image.height
        val plane = image.planes.firstOrNull() ?: return
        val source: ByteBuffer = plane.buffer.duplicate()
        val raw = ByteArray(source.remaining())
        source.get(raw)
        val pixelStride = plane.pixelStride
        val rowStride = plane.rowStride
        val packed = ByteArray(width * height * 4)

        for (y in 0 until height) {
            val sourceRow = y * rowStride
            val targetRow = y * width * 4
            for (x in 0 until width) {
                val sourceIndex = sourceRow + x * pixelStride
                val targetIndex = targetRow + x * 4
                if (sourceIndex + 3 < raw.size) {
                    packed[targetIndex] = raw[sourceIndex]
                    packed[targetIndex + 1] = raw[sourceIndex + 1]
                    packed[targetIndex + 2] = raw[sourceIndex + 2]
                    packed[targetIndex + 3] = raw[sourceIndex + 3]
                }
            }
        }

        val sensitivity = settings.getInt("sensitivity", 50).coerceIn(25, 85)
        val minArea = settings.getInt("min_area", 18).coerceIn(8, 44)
        val lineWidth = settings.getInt("line_width", 3).coerceIn(1, 8).toFloat()
        val found = DetectorBridge.detect(
            applicationContext, packed, width, height, sensitivity, minArea
        )
        overlay?.update(found, width, height, lineWidth)
    }

    private fun showOverlay() {
        if (!Settings.canDrawOverlays(this)) throw SecurityException("Overlay permission missing")
        windowManager = getSystemService(WINDOW_SERVICE) as WindowManager
        overlay = OverlayView(this)
        val params = WindowManager.LayoutParams(
            WindowManager.LayoutParams.MATCH_PARENT,
            WindowManager.LayoutParams.MATCH_PARENT,
            WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY,
            WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE or
                WindowManager.LayoutParams.FLAG_NOT_TOUCHABLE or
                WindowManager.LayoutParams.FLAG_LAYOUT_IN_SCREEN or
                WindowManager.LayoutParams.FLAG_LAYOUT_NO_LIMITS or
                WindowManager.LayoutParams.FLAG_SECURE,
            PixelFormat.TRANSLUCENT
        ).apply {
            gravity = Gravity.TOP or Gravity.START
        }
        windowManager?.addView(overlay, params)
    }

    private fun createNotificationChannel() {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            val channel = NotificationChannel(
                CHANNEL_ID,
                "TARGET OUTLINE screen analysis",
                NotificationManager.IMPORTANCE_LOW
            ).apply {
                description = "Shows when user-approved screen analysis is active"
                setShowBadge(false)
            }
            getSystemService(NotificationManager::class.java).createNotificationChannel(channel)
        }
    }

    private fun buildNotification(): Notification {
        val builder = if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            Notification.Builder(this, CHANNEL_ID)
        } else {
            @Suppress("DEPRECATION")
            Notification.Builder(this)
        }
        return builder
            .setContentTitle("TARGET OUTLINE активний")
            .setContentText("Екран обробляється локально. Повернись у застосунок, щоб зупинити.")
            .setSmallIcon(android.R.drawable.ic_menu_view)
            .setOngoing(true)
            .build()
    }

    override fun onDestroy() {
        try {
            projection?.let { activeProjection ->
                projectionCallback?.let { callback ->
                    runCatching { activeProjection.unregisterCallback(callback) }
                }
                runCatching { activeProjection.stop() }
            }
        } catch (error: Exception) {
            Log.w(TAG, "Projection cleanup warning", error)
        }
        projection = null
        projectionCallback = null
        runCatching { virtualDisplay?.release() }
        virtualDisplay = null
        runCatching { imageReader?.setOnImageAvailableListener(null, null) }
        runCatching { imageReader?.close() }
        imageReader = null
        runCatching { overlay?.let { windowManager?.removeView(it) } }
        overlay = null
        workerThread?.quitSafely()
        workerThread = null
        worker = null
        super.onDestroy()
    }
}
