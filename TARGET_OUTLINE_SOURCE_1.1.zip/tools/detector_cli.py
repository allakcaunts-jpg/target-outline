"""Run the same experimental detector on a raw RGBA file for smoke testing."""
import argparse
import json
from pathlib import Path
import sys

PROJECT = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(PROJECT / "app" / "src" / "main" / "python"))
from detector import detect_frame


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("rgba_file", help="Packed RGBA8888 image bytes")
    parser.add_argument("--width", type=int, required=True)
    parser.add_argument("--height", type=int, required=True)
    parser.add_argument("--sensitivity", type=int, default=50)
    parser.add_argument("--min-area", type=int, default=18)
    args = parser.parse_args()
    raw = Path(args.rgba_file).read_bytes()
    print(detect_frame(raw, args.width, args.height, args.sensitivity, args.min_area))


if __name__ == "__main__":
    main()
