import sys
import unittest
from pathlib import Path

PROJECT = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(PROJECT / "app" / "src" / "main" / "python"))
import detector


def make_frame(width, height, rectangles):
    data = bytearray(width * height * 4)
    for y in range(height):
        for x in range(width):
            i = (y * width + x) * 4
            data[i + 3] = 255
    for x1, y1, x2, y2, color in rectangles:
        for y in range(y1, y2):
            for x in range(x1, x2):
                i = (y * width + x) * 4
                data[i:i + 4] = bytes((*color, 255))
    return bytes(data)


class DetectorTests(unittest.TestCase):
    def setUp(self):
        detector.reset_tracking()

    def test_detects_large_saturated_candidate(self):
        width, height = 160, 120
        frame = make_frame(width, height, [(50, 30, 78, 78, (255, 40, 70))])
        import json
        boxes = json.loads(detector.detect_frame(frame, width, height))["boxes"]
        self.assertTrue(boxes)
        self.assertTrue(any(b[0] <= 52 and b[1] <= 32 and b[2] >= 76 and b[3] >= 76 for b in boxes))

    def test_rejects_neutral_background(self):
        width, height = 120, 90
        frame = make_frame(width, height, [(0, 0, 120, 90, (110, 110, 110))])
        import json
        boxes = json.loads(detector.detect_frame(frame, width, height))["boxes"]
        self.assertEqual(boxes, [])

    def test_rejects_tiny_color_noise(self):
        width, height = 120, 90
        frame = make_frame(width, height, [(40, 30, 46, 36, (20, 220, 240))])
        import json
        boxes = json.loads(detector.detect_frame(frame, width, height))["boxes"]
        self.assertEqual(boxes, [])

    def test_invalid_frame_returns_empty(self):
        import json
        self.assertEqual(json.loads(detector.detect_frame(b"", 10, 10))["boxes"], [])


if __name__ == "__main__":
    unittest.main(verbosity=2)
