package com.cart3r.targetoutline

import android.app.Activity
import android.content.Intent
import android.content.res.ColorStateList
import android.graphics.Color
import android.graphics.Typeface
import android.graphics.drawable.GradientDrawable
import android.media.projection.MediaProjectionManager
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.provider.Settings
import android.view.Gravity
import android.view.View
import android.view.ViewGroup
import android.widget.Button
import android.widget.LinearLayout
import android.widget.ScrollView
import android.widget.SeekBar
import android.widget.TextView
import android.widget.Toast

class MainActivity : Activity() {
    companion object {
        private const val REQUEST_CAPTURE = 4102
        private const val PREFS = "target_outline_settings"
        private const val BG = 0xFF08090D.toInt()
        private const val PANEL = 0xFF141720.toInt()
        private const val PANEL_ALT = 0xFF1A1E29.toInt()
        private const val RED = 0xFFFF3655.toInt()
        private const val WHITE = 0xFFF4F5F8.toInt()
        private const val MUTED = 0xFF9AA1B2.toInt()
    }

    private val prefs by lazy { getSharedPreferences(PREFS, MODE_PRIVATE) }
    private lateinit var statusValue: TextView
    private lateinit var statusDetail: TextView
    private lateinit var startButton: Button

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        window.statusBarColor = BG
        window.navigationBarColor = BG
        window.decorView.setBackgroundColor(BG)

        val screen = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setBackgroundColor(BG)
            fitsSystemWindows = true
            setPadding(dp(18), dp(10), dp(18), dp(8))
        }

        val header = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER_VERTICAL
            setPadding(dp(4), dp(5), dp(4), dp(12))
        }
        val brand = column().apply {
            addView(text("TARGET OUTLINE", 20f, RED, true))
            addView(text("REAL-TIME SCREEN ANALYSIS  /  v1.2.0", 9f, MUTED, true))
        }
        header.addView(brand, LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f))
        val badge = text("●  LOCAL MODE", 10f, 0xFFFFA1AD.toInt(), true).apply {
            background = rounded(0xFF35111A.toInt(), 0xFF783044.toInt(), 18)
            setPadding(dp(12), dp(8), dp(12), dp(8))
        }
        header.addView(badge)
        screen.addView(header)

        val scroll = ScrollView(this).apply {
            clipToPadding = false
            isFillViewport = false
            overScrollMode = View.OVER_SCROLL_IF_CONTENT_SCROLLS
        }
        val content = column()
        scroll.addView(content)
        screen.addView(scroll, LinearLayout.LayoutParams(
            ViewGroup.LayoutParams.MATCH_PARENT, 0, 1f
        ))
        setContentView(screen)

        buildHero(content)
        buildActions(content)
        buildSettings(content)
        buildAccuracyNotice(content)
        addFooter(content)
    }

    private fun buildHero(parent: LinearLayout) {
        val card = column().apply {
            background = rounded(PANEL, 0xFF51202D.toInt(), 20)
            setPadding(dp(18), dp(15), dp(18), dp(15))
        }
        val top = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER_VERTICAL
        }
        val title = column().apply {
            addView(text("LIVE VISUAL ASSIST", 18f, WHITE, true))
            addView(text("Visible objects only · no game access", 11f, MUTED, false))
        }
        top.addView(title, LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f))
        top.addView(text("READY", 10f, 0xFF7EE0A3.toInt(), true).apply {
            background = rounded(0xFF123323.toInt(), 0xFF286344.toInt(), 16)
            setPadding(dp(12), dp(7), dp(12), dp(7))
        })
        card.addView(top)

        val divider = View(this).apply { setBackgroundColor(0xFF292E3A.toInt()) }
        val dlp = LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, dp(1))
        dlp.setMargins(0, dp(13), 0, dp(11))
        card.addView(divider, dlp)

        val row = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL }
        val statusColumn = column()
        statusValue = text("NOT RUNNING", 13f, RED, true)
        statusDetail = text("Дозволи ще не перевірені", 10f, MUTED, false)
        statusColumn.addView(statusValue)
        statusColumn.addView(statusDetail)
        row.addView(statusColumn, LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f))
        row.addView(text("RED  /  3 PX", 11f, 0xFFFF8899.toInt(), true).apply {
            background = rounded(0xFF32131C.toInt(), 0xFF663041.toInt(), 14)
            setPadding(dp(11), dp(9), dp(11), dp(9))
        })
        card.addView(row)
        addGap(parent, 10)
        parent.addView(card)
    }

    private fun buildActions(parent: LinearLayout) {
        val actions = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER_VERTICAL
        }
        startButton = actionButton("START CAPTURE", RED, WHITE).apply {
            setOnClickListener { requestCapture() }
        }
        val stop = actionButton("STOP", PANEL_ALT, WHITE).apply {
            setOnClickListener {
                stopService(Intent(this@MainActivity, CaptureService::class.java))
                setStatus("STOPPED", "Захоплення екрана вимкнено", MUTED)
            }
        }
        actions.addView(startButton, LinearLayout.LayoutParams(0, dp(48), 1.45f).apply {
            marginEnd = dp(8)
        })
        actions.addView(stop, LinearLayout.LayoutParams(0, dp(48), 0.75f))
        addGap(parent, 10)
        parent.addView(actions)
    }

    private fun buildSettings(parent: LinearLayout) {
        val card = column().apply {
            background = rounded(PANEL, 0xFF292E3A.toInt(), 20)
            setPadding(dp(18), dp(15), dp(18), dp(15))
        }
        card.addView(text("НАЛАШТУВАННЯ ОБВЕДЕННЯ", 13f, WHITE, true))
        card.addView(text("Параметри зберігаються на телефоні", 10f, MUTED, false))
        addGap(card, 11)

        val colorRow = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER_VERTICAL
            background = rounded(PANEL_ALT, 0xFF303746.toInt(), 13)
            setPadding(dp(12), dp(9), dp(12), dp(9))
        }
        colorRow.addView(text("КОЛІР КОНТУРУ", 11f, MUTED, true), LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f))
        val swatch = View(this).apply { background = rounded(RED, RED, 8) }
        colorRow.addView(swatch, LinearLayout.LayoutParams(dp(22), dp(22)))
        val redLabel = text("  ЧЕРВОНИЙ", 11f, 0xFFFFA0AE.toInt(), true)
        colorRow.addView(redLabel)
        card.addView(colorRow)
        addGap(card, 8)

        addSlider(card, "Товщина лінії", "line_width", 1, 8, 3, "px")
        addSlider(card, "Чутливість сегментації", "sensitivity", 25, 85, 50, "%")
        addSlider(card, "Мінімальний розмір фрагмента", "min_area", 8, 44, 18, "ум. од.")

        card.addView(text("ЧАСТОТА АНАЛІЗУ КАДРІВ", 10f, MUTED, true).apply {
            setPadding(0, dp(9), 0, dp(6))
        })
        val fpsRow = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL }
        val fpsValues = listOf(6, 8, 10, 12, 15)
        val selectedFps = prefs.getInt("fps", 10)
        fpsValues.forEach { fps ->
            val chosen = fps == selectedFps
            val button = actionButton("${fps} FPS", if (chosen) RED else PANEL_ALT, if (chosen) WHITE else MUTED).apply {
                textSize = 10f
                setOnClickListener {
                    prefs.edit().putInt("fps", fps).apply()
                    // Recreate this settings panel so the selected state is visible immediately.
                    recreate()
                }
            }
            fpsRow.addView(button, LinearLayout.LayoutParams(0, dp(37), 1f).apply {
                if (fps != 15) marginEnd = dp(5)
            })
        }
        card.addView(fpsRow)
        addGap(parent, 10)
        parent.addView(card)
    }

    private fun addSlider(parent: LinearLayout, label: String, key: String, min: Int, max: Int, default: Int, unit: String) {
        val row = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER_VERTICAL
        }
        row.addView(text(label, 11f, WHITE, true), LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f))
        val valueText = text("${prefs.getInt(key, default)} $unit", 10f, 0xFFFFA0AE.toInt(), true)
        row.addView(valueText)
        parent.addView(row)

        val seek = SeekBar(this).apply {
            max = max - min
            progress = (prefs.getInt(key, default).coerceIn(min, max) - min)
            progressTintList = ColorStateList.valueOf(RED)
            progressBackgroundTintList = ColorStateList.valueOf(0xFF343A48.toInt())
            thumbTintList = ColorStateList.valueOf(RED)
            setOnSeekBarChangeListener(object : SeekBar.OnSeekBarChangeListener {
                override fun onProgressChanged(seekBar: SeekBar?, progress: Int, fromUser: Boolean) {
                    val value = min + progress
                    valueText.text = "$value $unit"
                    if (fromUser) prefs.edit().putInt(key, value).apply()
                }
                override fun onStartTrackingTouch(seekBar: SeekBar?) = Unit
                override fun onStopTrackingTouch(seekBar: SeekBar?) = Unit
            })
        }
        parent.addView(seek, LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, dp(34)))
    }

    private fun buildAccuracyNotice(parent: LinearLayout) {
        val notice = column().apply {
            background = rounded(0xFF211B13.toInt(), 0xFF6C4B23.toInt(), 16)
            setPadding(dp(15), dp(12), dp(15), dp(12))
        }
        notice.addView(text("ВАЖЛИВО ПРО ТОЧНІСТЬ", 11f, 0xFFFFC776.toInt(), true))
        addGap(notice, 4)
        notice.addView(text(
            "Ця збірка використовує локальну сегментацію кольорів і форм. Вона знаходить лише візуальні кандидати, а не розуміє, де саме боєць. Ефекти, декорації та інтерфейс можуть створювати хибні рамки. Для справжнього розпізнавання потрібна навчена модель і перевірка на кадрах гри.",
            10f, 0xFFD8C7A8.toInt(), false
        ))
        addGap(parent, 10)
        parent.addView(notice)
    }

    private fun addFooter(parent: LinearLayout) {
        addGap(parent, 9)
        parent.addView(text(
            "ЛОКАЛЬНА ОБРОБКА · БЕЗ МЕРЕЖЕВОГО ПЕРЕДАВАННЯ · MEDIA PROJECTION",
            8f, 0xFF687184.toInt(), true
        ).apply { gravity = Gravity.CENTER; setPadding(0, dp(3), 0, dp(8)) })
    }

    private fun requestCapture() {
        if (!Settings.canDrawOverlays(this)) {
            Toast.makeText(this, "Надай дозвіл «Поверх інших програм», потім натисни START ще раз", Toast.LENGTH_LONG).show()
            val intent = Intent(Settings.ACTION_MANAGE_OVERLAY_PERMISSION, Uri.parse("package:$packageName"))
            startActivity(intent)
            return
        }
        val manager = getSystemService(MEDIA_PROJECTION_SERVICE) as MediaProjectionManager
        startActivityForResult(manager.createScreenCaptureIntent(), REQUEST_CAPTURE)
    }

    @Deprecated("Required for the MediaProjection consent result on this Activity.")
    override fun onActivityResult(requestCode: Int, resultCode: Int, data: Intent?) {
        super.onActivityResult(requestCode, resultCode, data)
        if (requestCode != REQUEST_CAPTURE) return
        if (resultCode != RESULT_OK || data == null) {
            setStatus("NOT STARTED", "Дозвіл на захоплення не надано", MUTED)
            return
        }
        val serviceIntent = Intent(this, CaptureService::class.java).apply {
            action = CaptureService.ACTION_START
            putExtra(CaptureService.EXTRA_RESULT_CODE, resultCode)
            putExtra(CaptureService.EXTRA_DATA, data)
        }
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) startForegroundService(serviceIntent)
        else startService(serviceIntent)
        setStatus("CAPTURING", "Екран аналізується локально", 0xFF7EE0A3.toInt())
    }

    private fun setStatus(value: String, detail: String, color: Int) {
        if (::statusValue.isInitialized) {
            statusValue.text = value
            statusValue.setTextColor(color)
            statusDetail.text = detail
        }
    }

    private fun column() = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL }

    private fun text(value: String, size: Float, color: Int, bold: Boolean) = TextView(this).apply {
        text = value
        textSize = size
        setTextColor(color)
        if (bold) typeface = Typeface.create("sans-serif", Typeface.BOLD)
        includeFontPadding = false
    }

    private fun actionButton(label: String, backgroundColor: Int, textColor: Int) = Button(this).apply {
        text = label
        isAllCaps = false
        textSize = 12f
        typeface = Typeface.create("sans-serif", Typeface.BOLD)
        setTextColor(textColor)
        background = rounded(backgroundColor, if (backgroundColor == RED) RED else 0xFF343A48.toInt(), 14)
        stateListAnimator = null
        minHeight = 0
        minimumHeight = 0
        setPadding(dp(12), 0, dp(12), 0)
    }

    private fun rounded(fill: Int, stroke: Int, radius: Int) = GradientDrawable().apply {
        setColor(fill)
        setCornerRadius(dp(radius).toFloat())
        setStroke(dp(1), stroke)
    }

    private fun addGap(parent: LinearLayout, height: Int) {
        parent.addView(View(this), LinearLayout.LayoutParams(1, dp(height)))
    }

    private fun dp(value: Int): Int = (value * resources.displayMetrics.density).toInt()
}
